<?php
include '啟動Session.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Taipei');

// 建立資料庫連線
$servername = "localhost:3307"; 
$username = "root"; 
$password = "3307"; 
$dbname = "基金會"; 

$db_link = new mysqli($servername, $username, $password, $dbname);
if ($db_link->connect_error) { 
    die("連線失敗: " . $db_link->connect_error); 
}

// 接收表單送來的受款人代號
$search_count = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["受款人代號"])) {
    $search_count = $_POST["受款人代號"];
}

// 用 PDO 抓 uploads 檔案路徑
$csv_path = '';
$image_path = '';
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql_upload = "
        SELECT 
            u.csv_path,
            u.image_path
        FROM 經辦人交易檔 AS t
        JOIN uploads AS u ON t.交易單號 = u.交易單號
        WHERE t.受款人代號 = ?
        ORDER BY u.upload_timestamp DESC
        LIMIT 1
    ";
    $stmt_upload = $pdo->prepare($sql_upload);
    $stmt_upload->execute([$search_count]);
    $upload_data = $stmt_upload->fetch(PDO::FETCH_ASSOC);

    if ($upload_data) {
        $csv_path = $upload_data['csv_path'];
        $image_path = $upload_data['image_path'];
    }
} catch (PDOException $e) {
    die("資料庫連線失敗: " . $e->getMessage());
}

// 再用 mysqli 查主要資料
$result = false;
if (!empty($search_count)) {
    include '審查處理sql.php'; // 這裡是你的SQL語句
    $stmt = $db_link->prepare($sql);
    if (!$stmt) {
        die("SQL 錯誤：" . $db_link->error);
    }
    $stmt->bind_param("s", $search_count);
    $stmt->execute();
    $result = $stmt->get_result();
}

// 顯示資料
if ($result && $result->num_rows > 0) {
    echo "
    <form method='post' action='審核人審核意見.php'>
    <style>
        body {
            font-family: 'Noto Sans TC', Arial, sans-serif;
            background: linear-gradient(to bottom, #e8dff2, #f5e8fc);
            color: #333;
        }
        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 2px solid #e0e0e0;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #DEFFAC;
        }
        caption {
            font-size: 1.6em;
            margin: 15px;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        button {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            color: white;
            background-color: #4CAF50;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        textarea {
            width: 90%;
            height: 80px;
            margin: 20px auto;
            display: block;
            resize: none;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 10px;
        }
    </style>

    <table>
        <caption>檢視申請項目</caption>";

while ($row = $result->fetch_assoc()) {
    foreach ($row as $key => $value) {
        if (!empty($value)) { // ⭐️ 有值才顯示
            echo "<tr>
                <th>" . htmlspecialchars($key) . "</th>
                <td>" . htmlspecialchars($value) . "</td>
            </tr>";
        }
    }
}


    // 👉 重點：額外新增一排，只放 CSV 跟圖片下載
    echo "<tr>
        <th>CSV 下載</th>
        <td>" . (!empty($csv_path) ? "<a href='" . htmlspecialchars($csv_path) . "' target='_blank'>下載 CSV</a>" : "無檔案") . "</td>
    </tr>
    <tr>
        <th>圖片下載</th>
        <td>" . (!empty($image_path) ? "<a href='" . htmlspecialchars($image_path) . "' target='_blank'>下載圖片</a>" : "無圖片") . "</td>
    </tr>";

    echo "
    <tr>
        <td colspan='2'>
            <textarea name='opinion' placeholder='請輸入您的意見'></textarea>
        </td>
    </tr>
    <tr>
        <td colspan='2' class='button-container'>
            <input type='hidden' name='serial_count' value='" . htmlspecialchars($search_count) . "'>
            <button type='button' onclick='history.back()'>返回</button>
            <button type='submit' name='status' value='通過'>通過</button>
            <button type='submit' name='status' value='不通過'>不通過</button>
        </td>
    </tr>
    </table>
    </form>";
} else {
    echo "<p style='text-align: center;'>無法找到相關資料。</p>";
}

$db_link->close();
?>
